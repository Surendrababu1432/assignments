function hello(name)
{
   console.log("hello "+name);
}